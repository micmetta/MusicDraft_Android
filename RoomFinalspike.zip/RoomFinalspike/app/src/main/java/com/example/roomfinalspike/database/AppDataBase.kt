package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.data.Person
import com.example.data.PersonDao

@Database(
    // define the entities
    entities = [Person::class],
    version = 2
)
abstract class AppDataBase: RoomDatabase() {
    abstract fun personDao(): PersonDao?

    companion object {
        // marking the instance as volatile to ensure atomic access to the variable
        @Volatile
        private var INSTANCE: AppDataBase? = null

        fun getDatabase(context: Context): AppDataBase? {
         if (INSTANCE == null) {
            synchronized(AppDataBase::class.java) {
                if (INSTANCE == null) {
                    INSTANCE = androidx.room.Room.databaseBuilder(
                        context.applicationContext,
                        AppDataBase::class.java, "mobility_database"
                    )
                        // how to add a migration
                        .addMigrations(

                        )
                        // Wipes and rebuilds instead of migrating if no Migration object.
                        .fallbackToDestructiveMigration()
                        .addCallback(roomDatabaseCallback)
                        .build()
                }
            }
         }
            return INSTANCE
        }


    /**
     * Override the onOpen method to populate the database.
     * For this sample, we clear the database every time it is created or opened.
     * If you want to populate the database only when the database is created for the 1st time,
     * override MyRoomDatabase.Callback()#onCreate
     */
    private val roomDatabaseCallback: Callback =
        object : Callback() {
        }
}
}
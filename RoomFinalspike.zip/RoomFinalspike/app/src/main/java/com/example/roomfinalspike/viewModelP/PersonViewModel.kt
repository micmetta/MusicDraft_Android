package com.example.viewModelP

import androidx.lifecycle.ViewModel
import androidx.room.RoomDatabase
import androidx.sqlite.db.SimpleSQLiteQuery
import com.example.database.AppDataBase
import com.example.repository.PersonRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PersonViewModel(database: AppDataBase): ViewModel() {
    private var PersonDao = database.personDao()
    private val repository: PersonRepository = PersonRepository(this, PersonDao!!)
    var People = repository.People
        private set
    var selectedpeople =  repository.selectedPeople

    fun fetchCelestialBodyById(id: Int) {
        repository.getpeopleById(id)
    }

    fun init(){
        repository.init()
    }









}

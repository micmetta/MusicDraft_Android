package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.Person
import com.example.data.PersonDao
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

@Database(
    // define the entities
    entities = [Person::class],
    version = 2
)
abstract class AppDataBase: RoomDatabase() {
    abstract fun personDao(): PersonDao?

    companion object {
        // marking the instance as volatile to ensure atomic access to the variable
        @Volatile
        private var INSTANCE: AppDataBase? = null

        fun getDatabase(context: Context): AppDataBase? {
            val personDao = INSTANCE?.personDao()
         if (INSTANCE == null) {
            synchronized(AppDataBase::class.java) {
                if (INSTANCE == null) {

                    INSTANCE = androidx.room.Room.databaseBuilder(
                        context.applicationContext,
                        AppDataBase::class.java, "test_db"
                    )
                        // how to add a migration
                        .addMigrations(

                        )
                        // Wipes and rebuilds instead of migrating if no Migration object.
                        .fallbackToDestructiveMigration()
                        .addCallback(PrepopulateRoomCallback(context, personDao!!))
                        .build()
                }
            }
         }
            return INSTANCE
        }


    /**
     * Override the onOpen method to populate the database.
     * For this sample, we clear the database every time it is created or opened.
     * If you want to populate the database only when the database is created for the 1st time,
     * override MyRoomDatabase.Callback()#onCreate
     */
    private val roomDatabaseCallback: Callback =
        object : Callback() {

        }
}
}
class PrepopulateRoomCallback(private val context: Context, personDao: PersonDao) : RoomDatabase.Callback() {
    val database = AppDataBase.getDatabase(context)
    val personDao = database?.personDao()

    val callback = PrepopulateRoomCallback(context, personDao!!)
    val filePath = "C:\\Users\\pietr\\AndroidStudioProjects\\MyApplication1\\app\\src\\main\\java\\com\\example\\myapplication1\\database\\test_db.json"
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)

        CoroutineScope(Dispatchers.IO).launch {
            populateDatabase(personDao, filePath)
        }
    }

    fun readJsonFromFile(filePath: String): List<Person> {
        val gson = Gson()
        val file = File(filePath)
        val jsonContent = file.readText()
        return gson.fromJson(jsonContent, Array<Person>::class.java).toList()
    }
    suspend fun populateDatabase(personDao: PersonDao?, filePath: String) {
        val people = readJsonFromFile(filePath)
        if (personDao != null) {
            personDao.insertAll(people)
        }
    }

}

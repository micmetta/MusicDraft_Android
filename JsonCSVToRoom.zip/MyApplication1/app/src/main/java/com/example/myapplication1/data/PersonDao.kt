package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.sqlite.db.SupportSQLiteQuery
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Insert
    suspend fun insert(note: Person)

    @Insert
    suspend fun insertAll(list: List<Person>)

    @Query("Select * from Person where id = :id LIMIT 1")
    fun getPerson(id: Int): Flow<Person?>

    @Query("SELECT * FROM Person")
    fun getPeople(): Flow<List<Person>>


    companion object {
        fun <SimpleSQLiteQuery> insertDataRawFormat(query: SimpleSQLiteQuery) {

        }
    }
}
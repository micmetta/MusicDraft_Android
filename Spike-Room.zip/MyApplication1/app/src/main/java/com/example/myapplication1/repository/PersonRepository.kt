package com.example.repository

import android.os.Environment.getExternalStorageDirectory
import android.util.Log
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import androidx.room.RoomMasterTable.TABLE_NAME
import androidx.sqlite.db.SimpleSQLiteQuery
import com.example.CvsUtility.CSVReader
import com.example.viewModelP.PersonViewModel
import com.example.data.Person
import com.example.data.PersonDao
import com.example.database.AppDataBase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileReader

class PersonRepository(val viewModel: PersonViewModel, val dao:PersonDao) {
    var People = dao.getPeople()
    val selectedPeople: MutableStateFlow<Person?> = MutableStateFlow(null)

    suspend fun pushPeopleData(columns:StringBuilder,values:StringBuilder) = withContext(
        Dispatchers.IO){
        val query = SimpleSQLiteQuery(
            "INSERT INTO Person ($columns) values($values)",
            arrayOf()
        )
        com.example.data.PersonDao.insertDataRawFormat(query)
    }
    fun init(){
        viewModel.viewModelScope.launch {
            val csvReader =
                CSVReader(FileReader("test_table.csv"))/* path of local storage (it should be your csv file locatioin)*/
            var nextLine: Array<String> ? = null
            var count = 0
            val columns = StringBuilder()
            GlobalScope.launch(Dispatchers.IO) {
                do {
                    val value = StringBuilder()
                    nextLine = csvReader.readNext()
                    nextLine?.let {nextLine->
                        for (i in 0 until nextLine.size - 1) {
                            if (count == 0) {                             // the count==0 part only read
                                if (i == nextLine.size - 2) {             //your csv file column name
                                    columns.append(nextLine[i])
                                    count =1
                                }
                                else
                                    columns.append(nextLine[i]).append(",")
                            } else {                         // this part is for reading value of each row
                                if (i == nextLine.size - 2) {
                                    value.append("'").append(nextLine[i]).append("'")
                                    count = 2
                                }
                                else
                                    value.append("'").append(nextLine[i]).append("',")
                            }
                        }
                        if (count==2) {
                            pushPeopleData(columns, value)//write here your code to insert all values
                        }
                    }
                }while ((nextLine)!=null)
            }


        }
    }


    /**
     * it sets the celestialbody with id to
     * @param id
     */
    fun getpeopleById(id: Int) {
        viewModel.viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val PeopleBodyFlow = dao.getPerson(id)
                PeopleBodyFlow.collect { peopleBody ->
                    selectedPeople.value = peopleBody
                    Log.i("TG", "selectedPeople updated: $selectedPeople")
                }

            }
        }
    }
}